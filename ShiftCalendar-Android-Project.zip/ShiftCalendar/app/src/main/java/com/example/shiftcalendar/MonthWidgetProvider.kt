package com.example.shiftcalendar

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

class MonthWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.month_widget)
            val month = YearMonth.now()
            views.setTextViewText(R.id.widget_month, "${month.month.getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru")).replaceFirstChar { it.uppercase() }} ${month.year}")
            val intent = Intent(context, MonthWidgetService::class.java).apply { putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id); data = android.net.Uri.parse(toUri(Intent.URI_INTENT_SCHEME)) }
            views.setRemoteAdapter(R.id.widget_grid, intent)
            val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setPendingIntentTemplate(R.id.widget_grid, open)
            manager.updateAppWidget(id, views)
        }
    }
    companion object { fun refresh(c: Context) { val intent = Intent(c, MonthWidgetProvider::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE); val ids = AppWidgetManager.getInstance(c).getAppWidgetIds(ComponentName(c, MonthWidgetProvider::class.java)); intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids); c.sendBroadcast(intent) } }
}
