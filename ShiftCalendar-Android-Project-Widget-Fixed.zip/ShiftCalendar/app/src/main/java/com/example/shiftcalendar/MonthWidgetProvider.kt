package com.example.shiftcalendar

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

class MonthWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.month_widget)
            val month = YearMonth.now()
            views.setTextViewText(
                R.id.widget_month,
                "${month.month.getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru")).replaceFirstChar { it.uppercase() }} ${month.year}"
            )

            val first = month.atDay(1)
            val offset = first.dayOfWeek.value - 1
            for (index in 0 until 42) {
                val date = first.minusDays(offset.toLong()).plusDays(index.toLong())
                val row = index / 7
                val col = index % 7
                val cellId = context.resources.getIdentifier("day_${row}_${col}", "id", context.packageName)
                val inMonth = date.month == month.month
                val type = ShiftStore.type(context, date)
                val color = if (inMonth) ShiftStore.color(context, type) else 0xFF202D3D.toInt()
                views.setTextViewText(cellId, if (inMonth) date.dayOfMonth.toString() else "")
                views.setInt(cellId, "setBackgroundColor", color)
                views.setTextColor(cellId, if (inMonth) 0xFFF8FAFF.toInt() else 0xFF718096.toInt())
                views.setTextViewTextSize(cellId, android.util.TypedValue.COMPLEX_UNIT_SP, 16f)
                val open = Intent(context, MainActivity::class.java).apply {
                    putExtra("selected_date", date.toString())
                }
                val pending = android.app.PendingIntent.getActivity(
                    context, date.toEpochDay().toInt(), open,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(cellId, pending)
            }
            manager.updateAppWidget(id, views)
        }
    }

    companion object {
        fun refresh(c: Context) {
            val manager = AppWidgetManager.getInstance(c)
            val ids = manager.getAppWidgetIds(ComponentName(c, MonthWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                val intent = Intent(c, MonthWidgetProvider::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                c.sendBroadcast(intent)
            }
        }
    }
}
