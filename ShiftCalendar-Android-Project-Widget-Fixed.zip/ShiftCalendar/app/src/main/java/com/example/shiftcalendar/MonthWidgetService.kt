package com.example.shiftcalendar

import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import java.time.LocalDate
import java.time.YearMonth

class MonthWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = MonthFactory(applicationContext)
    class MonthFactory(private val context: Context) : RemoteViewsFactory {
        private var cells: List<LocalDate?> = emptyList()
        override fun onCreate() = Unit
        override fun onDataSetChanged() { cells = ShiftStore.monthCells(YearMonth.now()) }
        override fun onDestroy() = Unit
        override fun getCount() = cells.size
        override fun getViewAt(position: Int): RemoteViews {
            val date = cells[position]
            val rv = RemoteViews(context.packageName, R.layout.widget_day_cell)
            if (date == null) { rv.setTextViewText(R.id.day_number, ""); rv.setInt(R.id.day_number, "setBackgroundColor", 0xFF1C2A38.toInt()) }
            else {
                val type = ShiftStore.type(context, date)
                rv.setTextViewText(R.id.day_number, date.dayOfMonth.toString())
                rv.setInt(R.id.day_number, "setBackgroundColor", ShiftStore.color(context, type))
                val fillIntent = Intent(context, MainActivity::class.java)
                rv.setOnClickFillInIntent(R.id.day_number, fillIntent)
            }
            return rv
        }
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = cells[position]?.toEpochDay() ?: position.toLong()
        override fun hasStableIds() = true
    }
}
