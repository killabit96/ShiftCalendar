package com.example.shiftcalendar

import android.content.Context
import android.graphics.Color
import java.time.LocalDate
import java.time.YearMonth

object ShiftStore {
    const val DAY = 0
    const val NIGHT = 1
    const val OFF = 2
    const val EXTRA_WORK = 3
    const val EXTRA_OFF = 4
    const val DAY_OVERTIME = 5
    const val NIGHT_OVERTIME = 6
    private const val PREFS = "shift_calendar"
    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // Initial anchor is a sample only: 15 Oct 2026 is assumed to be a day shift until changed.
    private val anchor = LocalDate.of(2026, 10, 15)
    fun type(c: Context, date: LocalDate): Int {
        val key = "override_${date}"
        if (prefs(c).contains(key)) return prefs(c).getInt(key, OFF)
        val delta = java.time.temporal.ChronoUnit.DAYS.between(anchor, date).mod(4).toInt()
        return when (delta) { 0 -> DAY; 1 -> NIGHT; else -> OFF }
    }
    fun setType(c: Context, date: LocalDate, type: Int) { prefs(c).edit().putInt("override_${date}", type).apply(); MonthWidgetProvider.refresh(c) }
    fun color(c: Context, type: Int): Int {
        val defaults = intArrayOf(Color.rgb(0,132,255), Color.rgb(151,45,235), Color.rgb(48,183,77), Color.rgb(255,151,43), Color.rgb(35,190,190), Color.rgb(255,92,92), Color.rgb(232,93,158))
        return prefs(c).getInt("color_$type", defaults[type.coerceIn(0,6)])
    }
    fun setColor(c: Context, type: Int, color: Int) { prefs(c).edit().putInt("color_$type", color).apply(); MonthWidgetProvider.refresh(c) }
    fun label(type: Int) = when(type) { DAY -> "Дневная смена"; NIGHT -> "Ночная смена"; OFF -> "Выходной"; EXTRA_WORK -> "Доп. рабочий день"; EXTRA_OFF -> "Доп. выходной"; DAY_OVERTIME -> "Дневная подработка"; else -> "Ночная подработка" }
    fun monthCells(month: YearMonth): List<LocalDate> {
        val first = month.atDay(1)
        val offset = first.dayOfWeek.value - 1
        val count = 42
        return (0 until count).map { i -> first.plusDays((i - offset).toLong()) }
    }
}
