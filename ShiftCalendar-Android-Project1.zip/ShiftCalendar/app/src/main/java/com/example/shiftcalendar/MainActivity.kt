package com.example.shiftcalendar

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : Activity() {
    private var month = YearMonth.now()
    private lateinit var root: LinearLayout
    private lateinit var calendar: GridLayout
    private lateinit var title: TextView
    private val weekdays = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundColor(Color.rgb(8,17,28)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val prev = Button(this).apply { text = "‹"; setOnClickListener { month = month.minusMonths(1); render() } }
        title = TextView(this).apply { textSize = 21f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        val next = Button(this).apply { text = "›"; setOnClickListener { month = month.plusMonths(1); render() } }
        top.addView(prev, LinearLayout.LayoutParams(dp(48), dp(48))); top.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f)); top.addView(next, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(top)
        val head = GridLayout(this).apply { columnCount = 7 }
        weekdays.forEach { w -> head.addView(TextView(this).apply { text = w; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY); textSize = 12f }, GridLayout.LayoutParams().apply { width = 0; height = dp(30); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) }) }
        root.addView(head)
        calendar = GridLayout(this).apply { columnCount = 7; useDefaultMargins = false }
        root.addView(calendar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val income = Button(this).apply { text = "Мой доход за месяц"; setOnClickListener { showIncome() } }
        root.addView(income)
        val settings = Button(this).apply { text = "Настройки цветов"; setOnClickListener { showColors() } }
        root.addView(settings)
        setContentView(root)
        title.text = "${month.month.getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru")).replaceFirstChar { it.uppercase() }} ${month.year}"
        monthCellsRender()
    }
    private fun monthCellsRender() {
        calendar.removeAllViews()
        val cells = ShiftStore.monthCells(month)
        cells.forEach { date ->
            val cell = TextView(this).apply {
                gravity = Gravity.CENTER; textSize = 16f; setTextColor(Color.WHITE)
                text = date.dayOfMonth.toString()
                val baseColor = ShiftStore.color(this@MainActivity, ShiftStore.type(this@MainActivity, date))
                if (date.month == month.month && date.year == month.year) { setBackgroundColor(baseColor); setTextColor(Color.WHITE) } else { setBackgroundColor(Color.rgb(27,42,58)); setTextColor(Color.argb(115,210,225,242)) }
                if (date == LocalDate.now()) { setTypeface(null, Typeface.BOLD); setBackgroundResource(android.R.drawable.btn_default); setBackgroundTintList(android.content.res.ColorStateList.valueOf(ShiftStore.color(this@MainActivity, ShiftStore.type(this@MainActivity, date)))) }
                setOnClickListener { if (date != null) editDay(date) }
            }
            calendar.addView(cell, GridLayout.LayoutParams().apply { width = 0; height = 0; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(1), dp(1), dp(1), dp(1)) })
        }
    }
    private fun editDay(date: LocalDate) {
        val labels = (0..6).map { ShiftStore.label(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("${date.dayOfMonth}.${date.monthValue}.${date.year}")
            .setSingleChoiceItems(labels, ShiftStore.type(this, date)) { dialog, which -> ShiftStore.setType(this, date, which); dialog.dismiss(); render() }
            .setNegativeButton("Отмена", null).show()
    }

    private fun showIncome() {
        val summary = IncomeCalculator.calculate(this, month)
        val fmt = { value: Double -> IncomeCalculator.money(value) }
        val monthName = month.month.getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru")).replaceFirstChar { it.uppercase() }
        val message = buildString {
            append("Предварительный расчёт за $monthName ${month.year}\n\n")
            append("Дневных смен: ${summary.dayShifts}\n")
            append("Ночных смен: ${summary.nightShifts}\n")
            append("Подработок: ${summary.extraShifts}\n")
            append("Всего оплачиваемых смен: ${summary.dayShifts + summary.nightShifts + summary.extraShifts}\n")
            append("Оплачиваемые часы: ${summary.paidHours} ч\n")
            append("Ночные часы с доплатой: ${summary.nightHours} ч\n\n")
            append("Норма по производственному календарю: ${summary.monthlyNormHours} ч\n")
            append("Обычные часы по графику: ${summary.regularShiftHours} ч\n")
            append("Сверх нормы (оценка): ${summary.overtimeHours} ч\n")
            append("Доплата за сверхурочные (до налога): ${fmt(summary.overtimeGross)}\n")
            append("Сверхурочные на руки (оценка после 13%): ${fmt(summary.overtimeGross * (1.0 - IncomeCalculator.TAX_RATE))}\n")
            append("Из них уже начисляемая по графику оценка: ${fmt(summary.earnedOvertimeGross)}\n")
            append("Будущая доплата за сверхурочные: ${fmt(summary.futureOvertimeGross)}\n\n")
            append("Обычные смены по тарифу: ${fmt(summary.regularGross)}\n")
            append("Подработки (${IncomeCalculator.EXTRA_RATE} ₽/ч): ${fmt(summary.extraGross)}\n")
            append("Ночная доплата: ${fmt(summary.nightPremium)}\n")
            append("Доплата за особые условия: ${fmt(summary.difficultPay)}\n")
            append("Премия (предположительно 70%): ${fmt(summary.bonus)}\n")
            append("——————————————\n")
            append("Начислено до налога: ${fmt(summary.gross)}\n")
            append("НДФЛ (ориентировочно 13%): ${fmt(summary.tax)}\n")
            append("На руки за месяц: ${fmt(summary.net)}\n\n")
            append("Уже заработано по графику: ${fmt(summary.earnedNet)}\n")
            append("Ещё предстоит заработать: ${fmt(summary.futureNet)}\n\n")
            append("Подработка считается по ставке из квитков — 1 350,82 ₽/ч. Сверхурочные оцениваются отдельно по среднему фактическому начислению за май и июнь: 622,70 ₽/ч до налога (16 и 13 часов, всего 18 058,25 ₽). Это прогноз, не гарантированная бухгалтерская сумма. Норма 2026 года взята из производственного календаря для 40-часовой недели; для других лет используется приблизительный расчёт. В сверхурочные входят часы обычных дневных/ночных смен сверх нормы; отдельно оплачиваемые подработки исключены. Отпуска, больничные, отсутствия, неполный месяц и индивидуальные удержания могут изменить результат. «Уже» — оценка по завершившимся сменам календаря, а не подтверждение фактической отработки.")
        }
        val content = TextView(this).apply {
            text = message
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val scroll = android.widget.ScrollView(this).apply { addView(content) }
        AlertDialog.Builder(this)
            .setTitle("Мой доход — на руки")
            .setView(scroll)
            .setPositiveButton("Закрыть", null)
            .show()
            .window?.setBackgroundDrawableResource(android.R.color.background_dark)
    }

    private fun showColors() {
        val names = (0..6).map { ShiftStore.label(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Цвета смен").setItems(names) { _, which ->
            val choices = intArrayOf(Color.rgb(0,132,255), Color.rgb(151,45,235), Color.rgb(48,183,77), Color.rgb(255,151,43), Color.rgb(35,190,190), Color.RED, Color.YELLOW, Color.CYAN, Color.MAGENTA)
            val colors = arrayOf("Синий", "Фиолетовый", "Зелёный", "Оранжевый", "Бирюзовый", "Красный", "Жёлтый", "Голубой", "Пурпурный")
            AlertDialog.Builder(this).setTitle("Цвет: ${names[which]}").setItems(colors) { _, selected -> ShiftStore.setColor(this, which, choices[selected]); render() }.show()
        }.show()
    }
}
