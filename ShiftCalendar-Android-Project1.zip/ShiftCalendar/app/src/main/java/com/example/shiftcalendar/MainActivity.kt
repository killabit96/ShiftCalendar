package com.example.shiftcalendar

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : Activity() {
    private var month = YearMonth.now()
    private lateinit var root: LinearLayout
    private lateinit var calendar: GridLayout
    private lateinit var title: TextView
    private val weekdays = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)); setBackgroundColor(Color.rgb(8,17,28)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val prev = Button(this).apply { text = "‹"; setOnClickListener { month = month.minusMonths(1); render() } }
        title = TextView(this).apply { textSize = 21f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        val next = Button(this).apply { text = "›"; setOnClickListener { month = month.plusMonths(1); render() } }
        top.addView(prev, LinearLayout.LayoutParams(dp(48), dp(48))); top.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f)); top.addView(next, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(top)
        val head = GridLayout(this).apply { columnCount = 7 }
        weekdays.forEach { w -> head.addView(TextView(this).apply { text = w; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY); textSize = 12f }, GridLayout.LayoutParams().apply { width = 0; height = dp(30); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) }) }
        root.addView(head)
        calendar = GridLayout(this).apply { columnCount = 7; useDefaultMargins = false }
        root.addView(calendar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val settings = Button(this).apply { text = "Настройки цветов"; setOnClickListener { showColors() } }
        root.addView(settings)
        setContentView(root)
        title.text = "${month.month.getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru")).replaceFirstChar { it.uppercase() }} ${month.year}"
        monthCellsRender()
    }
    private fun monthCellsRender() {
        calendar.removeAllViews()
        val cells = ShiftStore.monthCells(month)
        cells.forEach { date ->
            val cell = TextView(this).apply {
                gravity = Gravity.CENTER; textSize = 16f; setTextColor(Color.WHITE)
                text = date?.dayOfMonth?.toString() ?: ""
                setBackgroundColor(if (date == null) Color.rgb(28,42,56) else ShiftStore.color(this@MainActivity, ShiftStore.type(this@MainActivity, date)))
                if (date == LocalDate.now()) { setTypeface(null, Typeface.BOLD); setBackgroundResource(android.R.drawable.btn_default); setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (date != null) ShiftStore.color(this@MainActivity, ShiftStore.type(this@MainActivity, date)) else Color.DKGRAY)) }
                setOnClickListener { if (date != null) editDay(date) }
            }
            calendar.addView(cell, GridLayout.LayoutParams().apply { width = 0; height = 0; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(1), dp(1), dp(1), dp(1)) })
        }
    }
    private fun editDay(date: LocalDate) {
        val labels = (0..4).map { ShiftStore.label(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("${date.dayOfMonth}.${date.monthValue}.${date.year}")
            .setSingleChoiceItems(labels, ShiftStore.type(this, date)) { dialog, which -> ShiftStore.setType(this, date, which); dialog.dismiss(); render() }
            .setNegativeButton("Отмена", null).show()
    }
    private fun showColors() {
        val names = (0..4).map { ShiftStore.label(it) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Цвета смен").setItems(names) { _, which ->
            val choices = intArrayOf(Color.rgb(0,132,255), Color.rgb(151,45,235), Color.rgb(48,183,77), Color.rgb(255,151,43), Color.rgb(35,190,190), Color.RED, Color.YELLOW, Color.CYAN, Color.MAGENTA)
            val colors = arrayOf("Синий", "Фиолетовый", "Зелёный", "Оранжевый", "Бирюзовый", "Красный", "Жёлтый", "Голубой", "Пурпурный")
            AlertDialog.Builder(this).setTitle("Цвет: ${names[which]}").setItems(colors) { _, selected -> ShiftStore.setColor(this, which, choices[selected]); render() }.show()
        }.show()
    }
}
