package com.example.shiftcalendar

import android.content.Context
import java.time.LocalDateTime
import java.time.YearMonth
import kotlin.math.roundToLong

data class IncomeSummary(
    val dayShifts: Int,
    val nightShifts: Int,
    val extraShifts: Int,
    val paidHours: Int,
    val nightHours: Int,
    val regularGross: Double,
    val extraGross: Double,
    val nightPremium: Double,
    val difficultPay: Double,
    val bonus: Double,
    val gross: Double,
    val tax: Double,
    val net: Double,
    val earnedGross: Double,
    val futureGross: Double,
    val earnedNet: Double,
    val futureNet: Double
)

object IncomeCalculator {
    const val HOURLY_RATE = 382.0
    const val NIGHT_RATE = 152.80
    const val DIFFICULT_RATE = 15.30
    const val BONUS_RATE = 0.70
    const val EXTRA_RATE = 1350.82
    const val TAX_RATE = 0.13
    const val SHIFT_HOURS = 12
    const val NIGHT_PREMIUM_HOURS = 8

    fun calculate(context: Context, month: YearMonth, asOf: LocalDateTime = LocalDateTime.now()): IncomeSummary {
        var dayCount = 0
        var nightCount = 0
        var extraCount = 0
        var earnedRegularGross = 0.0
        var futureRegularGross = 0.0
        var earnedExtraGross = 0.0
        var futureExtraGross = 0.0
        var earnedNightPremium = 0.0
        var futureNightPremium = 0.0
        var earnedDifficult = 0.0
        var futureDifficult = 0.0
        var earnedBonus = 0.0
        var futureBonus = 0.0

        val regularBasePerShift = SHIFT_HOURS * HOURLY_RATE
        val difficultPerShift = SHIFT_HOURS * DIFFICULT_RATE
        val bonusPerShift = (regularBasePerShift + difficultPerShift) * BONUS_RATE
        val extraPerShift = SHIFT_HOURS * EXTRA_RATE
        val nightPremiumPerShift = NIGHT_PREMIUM_HOURS * NIGHT_RATE

        for (day in 1..month.lengthOfMonth()) {
            val date = month.atDay(day)
            val type = ShiftStore.type(context, date)
            val endTime = when (type) {
                ShiftStore.NIGHT, ShiftStore.NIGHT_OVERTIME -> date.plusDays(1).atTime(8, 0)
                ShiftStore.DAY, ShiftStore.EXTRA_WORK, ShiftStore.DAY_OVERTIME -> date.atTime(20, 0)
                else -> null
            }
            val isEarned = endTime != null && !endTime.isAfter(asOf)
            when (type) {
                ShiftStore.DAY -> {
                    dayCount++
                    if (isEarned) {
                        earnedRegularGross += regularBasePerShift
                        earnedDifficult += difficultPerShift
                        earnedBonus += bonusPerShift
                    } else {
                        futureRegularGross += regularBasePerShift
                        futureDifficult += difficultPerShift
                        futureBonus += bonusPerShift
                    }
                }
                ShiftStore.NIGHT -> {
                    nightCount++
                    if (isEarned) {
                        earnedRegularGross += regularBasePerShift
                        earnedDifficult += difficultPerShift
                        earnedBonus += bonusPerShift
                        earnedNightPremium += nightPremiumPerShift
                    } else {
                        futureRegularGross += regularBasePerShift
                        futureDifficult += difficultPerShift
                        futureBonus += bonusPerShift
                        futureNightPremium += nightPremiumPerShift
                    }
                }
                ShiftStore.EXTRA_WORK, ShiftStore.DAY_OVERTIME, ShiftStore.NIGHT_OVERTIME -> {
                    extraCount++
                    if (isEarned) earnedExtraGross += extraPerShift else futureExtraGross += extraPerShift
                }
            }
        }

        val regularGross = earnedRegularGross + futureRegularGross
        val extraGross = earnedExtraGross + futureExtraGross
        val nightPremium = earnedNightPremium + futureNightPremium
        val difficultPay = earnedDifficult + futureDifficult
        val bonus = earnedBonus + futureBonus
        val gross = regularGross + extraGross + nightPremium + difficultPay + bonus
        val tax = (gross * TAX_RATE).roundToLongRubles()
        val net = gross - tax
        val earnedGross = earnedRegularGross + earnedExtraGross + earnedNightPremium + earnedDifficult + earnedBonus
        val futureGross = futureRegularGross + futureExtraGross + futureNightPremium + futureDifficult + futureBonus
        val earnedTax = if (gross > 0.0) (tax * earnedGross / gross).roundToLongRubles() else 0.0
        val earnedNet = earnedGross - earnedTax
        val futureNet = net - earnedNet

        return IncomeSummary(
            dayCount, nightCount, extraCount,
            (dayCount + nightCount + extraCount) * SHIFT_HOURS,
            nightCount * NIGHT_PREMIUM_HOURS,
            regularGross, extraGross, nightPremium, difficultPay, bonus,
            gross, tax, net, earnedGross, futureGross, earnedNet, futureNet
        )
    }

    private fun Double.roundToLongRubles(): Double = roundToLong().toDouble()

    fun money(value: Double): String {
        val fmt = java.text.NumberFormat.getNumberInstance(java.util.Locale("ru", "RU")).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
        return "${fmt.format(value)} ₽"
    }
}
