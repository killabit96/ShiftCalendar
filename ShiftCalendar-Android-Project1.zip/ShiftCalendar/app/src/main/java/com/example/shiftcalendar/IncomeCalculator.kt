package com.example.shiftcalendar

import android.content.Context
import java.time.LocalDateTime
import java.time.YearMonth
import kotlin.math.roundToLong

data class IncomeSummary(
    val dayShifts: Int,
    val nightShifts: Int,
    val extraShifts: Int,
    val paidHours: Int,
    val nightHours: Int,
    val regularGross: Double,
    val extraGross: Double,
    val nightPremium: Double,
    val difficultPay: Double,
    val bonus: Double,
    val gross: Double,
    val tax: Double,
    val net: Double,
    val earnedGross: Double,
    val futureGross: Double,
    val earnedNet: Double,
    val futureNet: Double,
    val monthlyNormHours: Int,
    val regularShiftHours: Int,
    val overtimeHours: Int,
    val overtimeGross: Double,
    val earnedOvertimeGross: Double,
    val futureOvertimeGross: Double
)

/**
 * Monthly norm for a standard Russian five-day, 40-hour workweek.
 * The 2026 values are the published production-calendar norms. Other years
 * use a transparent weekday-based approximation until a year-specific table
 * is added (holiday transfers can make the approximation differ from the official calendar).
 */
object ProductionCalendar {
    private val norm2026 = intArrayOf(120, 152, 168, 175, 151, 167, 184, 168, 176, 176, 159, 176)

    fun normHours(month: YearMonth): Int {
        if (month.year == 2026) return norm2026[month.monthValue - 1]
        var weekdays = 0
        var reducedDays = 0
        var date = month.atDay(1)
        while (date.month == month.month) {
            if (date.dayOfWeek.value <= 5) weekdays++
            // Approximate national holidays and pre-holiday reductions.
            if (date.dayOfWeek.value <= 5 && isFixedNonWorkingHoliday(date)) weekdays--
            if (date.dayOfWeek.value <= 5 && isKnownShortenedPreHoliday(date)) reducedDays++
            date = date.plusDays(1)
        }
        return (weekdays * 8 - reducedDays).coerceAtLeast(0)
    }

    private fun isFixedNonWorkingHoliday(date: java.time.LocalDate): Boolean = when (date.monthValue) {
        1 -> date.dayOfMonth in 1..8
        2 -> date.dayOfMonth == 23
        3 -> date.dayOfMonth == 8
        5 -> date.dayOfMonth == 1 || date.dayOfMonth == 9
        6 -> date.dayOfMonth == 12
        11 -> date.dayOfMonth == 4
        else -> false
    }

    private fun isKnownShortenedPreHoliday(date: java.time.LocalDate): Boolean =
        (date.monthValue == 4 && date.dayOfMonth == 30) ||
        (date.monthValue == 5 && date.dayOfMonth == 8) ||
        (date.monthValue == 6 && date.dayOfMonth == 11) ||
        (date.monthValue == 11 && date.dayOfMonth == 3) ||
        (date.monthValue == 12 && date.dayOfMonth == 31)
}

object IncomeCalculator {
    const val HOURLY_RATE = 382.0
    const val NIGHT_RATE = 152.80
    const val DIFFICULT_RATE = 15.30
    const val BONUS_RATE = 0.70
    const val EXTRA_RATE = 1350.82
    const val TAX_RATE = 0.13
    // Empirical estimate from the user's May and June 2026 payslips:
    // (9,277.92 + 8,780.33) / (16 + 13) = 622.70 RUB per overtime hour.
    // This is an estimate of the separate payslip line, not a legal payroll guarantee.
    const val OVERTIME_ESTIMATED_RATE = 622.70
    const val SHIFT_HOURS = 12
    const val NIGHT_PREMIUM_HOURS = 8

    fun calculate(context: Context, month: YearMonth, asOf: LocalDateTime = LocalDateTime.now()): IncomeSummary {
        var dayCount = 0
        var nightCount = 0
        var extraCount = 0
        var earnedRegularGross = 0.0
        var futureRegularGross = 0.0
        var earnedExtraGross = 0.0
        var futureExtraGross = 0.0
        var earnedNightPremium = 0.0
        var futureNightPremium = 0.0
        var earnedDifficult = 0.0
        var futureDifficult = 0.0
        var earnedBonus = 0.0
        var futureBonus = 0.0
        val regularShifts = mutableListOf<Pair<LocalDateTime, Boolean>>()

        val regularBasePerShift = SHIFT_HOURS * HOURLY_RATE
        val difficultPerShift = SHIFT_HOURS * DIFFICULT_RATE
        val bonusPerShift = (regularBasePerShift + difficultPerShift) * BONUS_RATE
        val extraPerShift = SHIFT_HOURS * EXTRA_RATE
        val nightPremiumPerShift = NIGHT_PREMIUM_HOURS * NIGHT_RATE

        for (day in 1..month.lengthOfMonth()) {
            val date = month.atDay(day)
            val type = ShiftStore.type(context, date)
            val endTime = when (type) {
                ShiftStore.NIGHT, ShiftStore.NIGHT_OVERTIME -> date.plusDays(1).atTime(8, 0)
                ShiftStore.DAY, ShiftStore.EXTRA_WORK, ShiftStore.DAY_OVERTIME -> date.atTime(20, 0)
                else -> null
            }
            val isEarned = endTime != null && !endTime.isAfter(asOf)
            when (type) {
                ShiftStore.DAY -> {
                    dayCount++
                    regularShifts += date.atTime(20, 0) to isEarned
                    if (isEarned) {
                        earnedRegularGross += regularBasePerShift
                        earnedDifficult += difficultPerShift
                        earnedBonus += bonusPerShift
                    } else {
                        futureRegularGross += regularBasePerShift
                        futureDifficult += difficultPerShift
                        futureBonus += bonusPerShift
                    }
                }
                ShiftStore.NIGHT -> {
                    nightCount++
                    regularShifts += date.plusDays(1).atTime(8, 0) to isEarned
                    if (isEarned) {
                        earnedRegularGross += regularBasePerShift
                        earnedDifficult += difficultPerShift
                        earnedBonus += bonusPerShift
                        earnedNightPremium += nightPremiumPerShift
                    } else {
                        futureRegularGross += regularBasePerShift
                        futureDifficult += difficultPerShift
                        futureBonus += bonusPerShift
                        futureNightPremium += nightPremiumPerShift
                    }
                }
                ShiftStore.EXTRA_WORK, ShiftStore.DAY_OVERTIME, ShiftStore.NIGHT_OVERTIME -> {
                    extraCount++
                    if (isEarned) earnedExtraGross += extraPerShift else futureExtraGross += extraPerShift
                }
            }
        }

        // Count overtime only on ordinary DAY/NIGHT shifts. Extra shifts marked
        // EXTRA_WORK / *_OVERTIME are separately paid at the extra-shift rate and
        // are deliberately excluded to avoid double counting.
        val monthlyNorm = ProductionCalendar.normHours(month)
        var cumulativeRegularHours = 0
        var overtimeHours = 0
        var earnedOvertimeGross = 0.0
        var futureOvertimeGross = 0.0
        regularShifts.sortedBy { it.first }.forEach { (_, isEarned) ->
            val before = cumulativeRegularHours
            cumulativeRegularHours += SHIFT_HOURS
            val overtimeInShift = (cumulativeRegularHours - monthlyNorm).coerceAtLeast(0) - (before - monthlyNorm).coerceAtLeast(0)
            if (overtimeInShift > 0) {
                overtimeHours += overtimeInShift
                val amount = overtimeInShift * OVERTIME_ESTIMATED_RATE
                if (isEarned) earnedOvertimeGross += amount else futureOvertimeGross += amount
            }
        }
        val overtimeGross = earnedOvertimeGross + futureOvertimeGross
        val regularShiftHours = (dayCount + nightCount) * SHIFT_HOURS
        val regularGross = earnedRegularGross + futureRegularGross
        val extraGross = earnedExtraGross + futureExtraGross
        val nightPremium = earnedNightPremium + futureNightPremium
        val difficultPay = earnedDifficult + futureDifficult
        val bonus = earnedBonus + futureBonus
        val gross = regularGross + extraGross + nightPremium + difficultPay + bonus + overtimeGross
        val tax = (gross * TAX_RATE).roundToLongRubles()
        val net = gross - tax
        val earnedGross = earnedRegularGross + earnedExtraGross + earnedNightPremium + earnedDifficult + earnedBonus + earnedOvertimeGross
        val futureGross = futureRegularGross + futureExtraGross + futureNightPremium + futureDifficult + futureBonus + futureOvertimeGross
        val earnedTax = if (gross > 0.0) (tax * earnedGross / gross).roundToLongRubles() else 0.0
        val earnedNet = earnedGross - earnedTax
        val futureNet = net - earnedNet

        return IncomeSummary(
            dayCount, nightCount, extraCount,
            (dayCount + nightCount + extraCount) * SHIFT_HOURS,
            nightCount * NIGHT_PREMIUM_HOURS,
            regularGross, extraGross, nightPremium, difficultPay, bonus,
            gross, tax, net, earnedGross, futureGross, earnedNet, futureNet,
            monthlyNorm, regularShiftHours, overtimeHours, overtimeGross,
            earnedOvertimeGross, futureOvertimeGross
        )
    }

    private fun Double.roundToLongRubles(): Double = roundToLong().toDouble()

    fun money(value: Double): String {
        val fmt = java.text.NumberFormat.getNumberInstance(java.util.Locale("ru", "RU")).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
        return "${fmt.format(value)} ₽"
    }
}
