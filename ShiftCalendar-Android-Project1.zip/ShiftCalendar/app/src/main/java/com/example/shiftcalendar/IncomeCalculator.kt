package com.example.shiftcalendar

import android.content.Context
import java.time.LocalDateTime
import java.time.YearMonth
import kotlin.math.roundToLong

data class IncomeSummary(
    val dayShifts: Int,
    val nightShifts: Int,
    val extraShifts: Int,
    val paidHours: Int,
    val nightHours: Int,
    val regularGross: Double,
    val extraGross: Double,
    val nightPremium: Double,
    val difficultPay: Double,
    val bonus: Double,
    val gross: Double,
    val tax: Double,
    val net: Double,
    val earnedGross: Double,
    val futureGross: Double,
    val earnedNet: Double,
    val futureNet: Double,
    val monthlyNormHours: Int,
    val regularShiftHours: Int,
    val overtimeHours: Int,
    val overtimeGross: Double,
    val earnedOvertimeGross: Double,
    val futureOvertimeGross: Double
)

/**
 * Monthly norm for a standard Russian five-day, 40-hour workweek.
 * The 2026 values are the published production-calendar norms. Other years
 * use a transparent weekday-based approximation until a year-specific table
 * is added (holiday transfers can make the approximation differ from the official calendar).
 */
object ProductionCalendar {
    private val norm2026 = intArrayOf(120, 152, 168, 175, 151, 167, 184, 168, 176, 176, 159, 176)

    fun normHours(month: YearMonth): Int {
        if (month.year == 2026) return norm2026[month.monthValue - 1]
        var weekdays = 0
        var reducedDays = 0
        var date = month.atDay(1)
        while (date.month == month.month) {
            if (date.dayOfWeek.value <= 5) weekdays++
            // Approximate national holidays and pre-holiday reductions.
            if (date.dayOfWeek.value <= 5 && isFixedNonWorkingHoliday(date)) weekdays--
            if (date.dayOfWeek.value <= 5 && isKnownShortenedPreHoliday(date)) reducedDays++
            date = date.plusDays(1)
        }
        return (weekdays * 8 - reducedDays).coerceAtLeast(0)
    }

    private fun isFixedNonWorkingHoliday(date: java.time.LocalDate): Boolean = when (date.monthValue) {
        1 -> date.dayOfMonth in 1..8
        2 -> date.dayOfMonth == 23
        3 -> date.dayOfMonth == 8
        5 -> date.dayOfMonth == 1 || date.dayOfMonth == 9
        6 -> date.dayOfMonth == 12
        11 -> date.dayOfMonth == 4
        else -> false
    }

    private fun isKnownShortenedPreHoliday(date: java.time.LocalDate): Boolean =
        (date.monthValue == 4 && date.dayOfMonth == 30) ||
        (date.monthValue == 5 && date.dayOfMonth == 8) ||
        (date.monthValue == 6 && date.dayOfMonth == 11) ||
        (date.monthValue == 11 && date.dayOfMonth == 3) ||
        (date.monthValue == 12 && date.dayOfMonth == 31)
}

object IncomeCalculator {
    const val HOURLY_RATE = 382.0
    const val NIGHT_RATE = 152.80
    const val DIFFICULT_RATE = 15.30
    const val BONUS_RATE = 0.70
    const val EXTRA_RATE = 1350.82
    const val TAX_RATE = 0.13
    // Empirical estimate from the user's May and June 2026 payslips:
    // (9,277.92 + 8,780.33) / (16 + 13) = 622.70 RUB per overtime hour.
    // This is an estimate of the separate payslip line, not a legal payroll guarantee.
    const val OVERTIME_ESTIMATED_RATE = 622.70
    const val SHIFT_HOURS = 12
    const val NIGHT_PREMIUM_HOURS = 8

    fun calculate(context: Context, month: YearMonth, asOf: LocalDateTime = LocalDateTime.now()): IncomeSummary {
        var dayCount = 0
        var nightCount = 0
        var extraCount = 0
        var earnedRegularGross = 0.0
        var futureRegularGross = 0.0
        var earnedExtraGross = 0.0
        var futureExtraGross = 0.0
        var earnedNightPremium = 0.0
        var futureNightPremium = 0.0
        var earnedDifficult = 0.0
        var futureDifficult = 0.0
        var earnedBonus = 0.0
        var futureBonus = 0.0
        // Each entry is a worked segment inside this calendar month: end time, hours, earned.
        val regularSegments = mutableListOf<Triple<LocalDateTime, Int, Boolean>>()
        var totalRegularHoursInMonth = 0
        var totalExtraHoursInMonth = 0
        var nightPremiumHoursInMonth = 0

        val monthStart = month.atDay(1).atStartOfDay()
        val monthEnd = month.plusMonths(1).atDay(1).atStartOfDay()
        val extraHourlyGross = EXTRA_RATE

        // Include the previous day so the 00:00–08:00 part of a night shift
        // that began in the previous month is credited to this month.
        var date = month.atDay(1).minusDays(1)
        while (date.isBefore(month.plusMonths(1).atDay(1))) {
            val type = ShiftStore.type(context, date)
            val isNight = type == ShiftStore.NIGHT || type == ShiftStore.NIGHT_OVERTIME
            val isDay = type == ShiftStore.DAY || type == ShiftStore.DAY_OVERTIME || type == ShiftStore.EXTRA_WORK
            if (date.yearMonth() == month) {
                when (type) {
                    ShiftStore.DAY -> dayCount++
                    ShiftStore.NIGHT -> nightCount++
                    ShiftStore.EXTRA_WORK, ShiftStore.DAY_OVERTIME, ShiftStore.NIGHT_OVERTIME -> extraCount++
                }
            }

            if (isNight || isDay) {
                val shiftStart = if (isNight) date.atTime(20, 0) else date.atTime(8, 0)
                val shiftEnd = if (isNight) date.plusDays(1).atTime(8, 0) else date.atTime(20, 0)
                val segmentStart = if (shiftStart.isAfter(monthStart)) shiftStart else monthStart
                val segmentEnd = if (shiftEnd.isBefore(monthEnd)) shiftEnd else monthEnd
                if (segmentEnd.isAfter(segmentStart)) {
                    // Shift segments are whole-hour aligned: day shifts 12h; night shifts split 4h/8h at midnight.
                    val hours = java.time.Duration.between(segmentStart, segmentEnd).toHours().toInt()
                    if (hours > 0) {
                        val earned = !segmentEnd.isAfter(asOf)
                        if (type == ShiftStore.DAY || type == ShiftStore.NIGHT) {
                            totalRegularHoursInMonth += hours
                            regularSegments += Triple(segmentEnd, hours, earned)
                            val base = hours * HOURLY_RATE
                            val difficult = hours * DIFFICULT_RATE
                            val bonus = (HOURLY_RATE + DIFFICULT_RATE) * BONUS_RATE * hours
                            if (earned) {
                                earnedRegularGross += base
                                earnedDifficult += difficult
                                earnedBonus += bonus
                            } else {
                                futureRegularGross += base
                                futureDifficult += difficult
                                futureBonus += bonus
                            }
                        } else {
                            totalExtraHoursInMonth += hours
                            val extra = hours * extraHourlyGross
                            if (earned) earnedExtraGross += extra else futureExtraGross += extra
                        }
                    }
                }

                // Night premium applies from 22:00 to 06:00. Split it at midnight too,
                // so only the 22:00–24:00 portion belongs to the starting month.
                if (isNight) {
                    val premiumStart = date.atTime(22, 0)
                    val premiumEnd = date.plusDays(1).atTime(6, 0)
                    val pStart = if (premiumStart.isAfter(monthStart)) premiumStart else monthStart
                    val pEnd = if (premiumEnd.isBefore(monthEnd)) premiumEnd else monthEnd
                    if (pEnd.isAfter(pStart)) {
                        val premiumHours = java.time.Duration.between(pStart, pEnd).toHours().toInt()
                        if (premiumHours > 0) {
                            nightPremiumHoursInMonth += premiumHours
                            val premium = premiumHours * NIGHT_RATE
                            if (!pEnd.isAfter(asOf)) earnedNightPremium += premium else futureNightPremium += premium
                        }
                    }
                }
            }
            date = date.plusDays(1)
        }

        // Count overtime only on ordinary DAY/NIGHT hours in this month. Explicit extra
        // shifts remain separately paid at EXTRA_RATE and are excluded from the norm.
        val monthlyNorm = ProductionCalendar.normHours(month)
        var cumulativeRegularHours = 0
        var overtimeHours = 0
        var earnedOvertimeGross = 0.0
        var futureOvertimeGross = 0.0
        regularSegments.sortedBy { it.first }.forEach { (_, hours, isEarned) ->
            val before = cumulativeRegularHours
            cumulativeRegularHours += hours
            val overtimeInSegment = (cumulativeRegularHours - monthlyNorm).coerceAtLeast(0) -
                (before - monthlyNorm).coerceAtLeast(0)
            if (overtimeInSegment > 0) {
                overtimeHours += overtimeInSegment
                val amount = overtimeInSegment * OVERTIME_ESTIMATED_RATE
                if (isEarned) earnedOvertimeGross += amount else futureOvertimeGross += amount
            }
        }
        val overtimeGross = earnedOvertimeGross + futureOvertimeGross
        val regularShiftHours = totalRegularHoursInMonth
        val regularGross = earnedRegularGross + futureRegularGross
        val extraGross = earnedExtraGross + futureExtraGross
        val nightPremium = earnedNightPremium + futureNightPremium
        val difficultPay = earnedDifficult + futureDifficult
        val bonus = earnedBonus + futureBonus
        val gross = regularGross + extraGross + nightPremium + difficultPay + bonus + overtimeGross
        val tax = (gross * TAX_RATE).roundToLongRubles()
        val net = gross - tax
        val earnedGross = earnedRegularGross + earnedExtraGross + earnedNightPremium + earnedDifficult + earnedBonus + earnedOvertimeGross
        val futureGross = futureRegularGross + futureExtraGross + futureNightPremium + futureDifficult + futureBonus + futureOvertimeGross
        val earnedTax = if (gross > 0.0) (tax * earnedGross / gross).roundToLongRubles() else 0.0
        val earnedNet = earnedGross - earnedTax
        val futureNet = net - earnedNet

        return IncomeSummary(
            dayCount, nightCount, extraCount,
            totalRegularHoursInMonth + totalExtraHoursInMonth,
            nightPremiumHoursInMonth,
            regularGross, extraGross, nightPremium, difficultPay, bonus,
            gross, tax, net, earnedGross, futureGross, earnedNet, futureNet,
            monthlyNorm, regularShiftHours, overtimeHours, overtimeGross,
            earnedOvertimeGross, futureOvertimeGross
        )
    }

    private fun java.time.LocalDate.yearMonth(): YearMonth = YearMonth.of(year, month)

    private fun Double.roundToLongRubles(): Double = roundToLong().toDouble()

    fun money(value: Double): String {
        val fmt = java.text.NumberFormat.getNumberInstance(java.util.Locale("ru", "RU")).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }
        return "${fmt.format(value)} ₽"
    }
}
