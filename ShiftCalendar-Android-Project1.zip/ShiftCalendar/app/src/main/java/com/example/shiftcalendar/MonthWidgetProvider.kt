package com.example.shiftcalendar

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

class MonthWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_PREVIOUS -> changeMonth(context, -1)
            ACTION_NEXT -> changeMonth(context, 1)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
    }

    private fun changeMonth(context: Context, delta: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val offset = prefs.getInt(MONTH_OFFSET, 0) + delta
        prefs.edit().putInt(MONTH_OFFSET, offset).apply()
        refresh(context)
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
        val views = RemoteViews(context.packageName, R.layout.month_widget)
        val offset = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(MONTH_OFFSET, 0)
        val month = YearMonth.now().plusMonths(offset.toLong())
        val monthName = month.month.getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru")).replaceFirstChar { it.uppercase() }
        views.setTextViewText(R.id.widget_month, "$monthName ${month.year}")
        views.setTextViewText(R.id.widget_month, "$monthName ${month.year}")

        views.setOnClickPendingIntent(R.id.widget_prev_month, PendingIntent.getBroadcast(context, 101, Intent(context, MonthWidgetProvider::class.java).setAction(ACTION_PREVIOUS), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        views.setOnClickPendingIntent(R.id.widget_next_month, PendingIntent.getBroadcast(context, 102, Intent(context, MonthWidgetProvider::class.java).setAction(ACTION_NEXT), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

        views.removeAllViews(R.id.widget_grid)
        val cells = ShiftStore.monthCells(month)
        cells.chunked(7).forEachIndexed { rowIndex, rowCells ->
            val row = RemoteViews(context.packageName, R.layout.widget_calendar_row)
            rowCells.forEachIndexed { colIndex, date ->
                val cell = RemoteViews(context.packageName, R.layout.widget_day_cell)
                if (date.month != month.month || date.year != month.year) {
                    cell.setTextViewText(R.id.day_number, date.dayOfMonth.toString())
                    cell.setInt(R.id.day_number, "setBackgroundResource", R.drawable.day_cell_empty)
                    cell.setTextColor(R.id.day_number, android.graphics.Color.argb(125,210,225,242))
                    val open = Intent(context, MainActivity::class.java).putExtra("selected_date", date.toString())
                    cell.setOnClickPendingIntent(R.id.day_number, PendingIntent.getActivity(context, date.toEpochDay().toInt(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                } else {
                    val type = ShiftStore.type(context, date)
                    cell.setTextViewText(R.id.day_number, date.dayOfMonth.toString())
                    val color = ShiftStore.color(context, type)
                    val palette = intArrayOf(android.graphics.Color.rgb(0,132,255), android.graphics.Color.rgb(151,45,235), android.graphics.Color.rgb(48,183,77), android.graphics.Color.rgb(255,151,43), android.graphics.Color.rgb(35,190,190), android.graphics.Color.RED, android.graphics.Color.YELLOW, android.graphics.Color.CYAN, android.graphics.Color.MAGENTA)
                    val backgrounds = intArrayOf(R.drawable.day_color_0, R.drawable.day_color_1, R.drawable.day_color_2, R.drawable.day_color_3, R.drawable.day_color_4, R.drawable.day_color_5, R.drawable.day_color_6, R.drawable.day_color_7, R.drawable.day_color_8)
                    val colorIndex = palette.indexOf(color)
                    if (colorIndex >= 0) cell.setInt(R.id.day_number, "setBackgroundResource", backgrounds[colorIndex]) else cell.setInt(R.id.day_number, "setBackgroundColor", color)
                    val open = Intent(context, MainActivity::class.java).putExtra("selected_date", date.toString())
                    val pi = PendingIntent.getActivity(context, date.toEpochDay().toInt(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    cell.setOnClickPendingIntent(R.id.day_number, pi)
                }
                row.addView(R.id.widget_row, cell)
            }
            views.addView(R.id.widget_grid, row)
        }

        val today = LocalDate.now()
        val nowDateTime = java.time.LocalDateTime.now()
        val todayType = ShiftStore.type(context, today)
        val now = nowDateTime.toLocalTime()
        val workingToday = todayType == ShiftStore.DAY || todayType == ShiftStore.NIGHT || todayType == ShiftStore.EXTRA_WORK || todayType == ShiftStore.DAY_OVERTIME || todayType == ShiftStore.NIGHT_OVERTIME
        val currentShift = if (workingToday && (((todayType == ShiftStore.DAY || todayType == ShiftStore.DAY_OVERTIME || todayType == ShiftStore.EXTRA_WORK) && now.hour in 8..19) || ((todayType == ShiftStore.NIGHT || todayType == ShiftStore.NIGHT_OVERTIME) && (now.hour >= 20 || now.hour < 8)))) todayType else -1
        val currentText = if (currentShift >= 0) {
            val end = if (currentShift == ShiftStore.DAY || currentShift == ShiftStore.DAY_OVERTIME || currentShift == ShiftStore.EXTRA_WORK) today.atTime(20, 0) else if (now.hour < 8) today.atTime(8, 0) else today.plusDays(1).atTime(8, 0)
            val mins = java.time.Duration.between(nowDateTime, end).toMinutes().coerceAtLeast(0)
            "Сейчас: ${ShiftStore.label(currentShift).lowercase(Locale("ru"))} · осталось ${mins / 60} ч ${mins % 60} мин"
        } else null

        // Find the next scheduled shift start strictly in the future.
        val nextShift = (0L..60L).asSequence().map { today.plusDays(it) }.mapNotNull { date ->
            val type = ShiftStore.type(context, date)
            val isDay = type == ShiftStore.DAY || type == ShiftStore.DAY_OVERTIME || type == ShiftStore.EXTRA_WORK
            val isNight = type == ShiftStore.NIGHT || type == ShiftStore.NIGHT_OVERTIME
            if (!isDay && !isNight) null else {
                val startTime = if (isNight) date.atTime(20, 0) else date.atTime(8, 0)
                if (startTime.isAfter(nowDateTime)) Triple(date, type, startTime) else null
            }
        }.firstOrNull()
        val countdownText = if (nextShift == null) "До следующей смены: не найдена" else {
            val (date, type, startTime) = nextShift
            val totalMinutes = java.time.Duration.between(nowDateTime, startTime).toMinutes().coerceAtLeast(0)
            val days = totalMinutes / (24 * 60)
            val hours = (totalMinutes % (24 * 60)) / 60
            val minutes = totalMinutes % 60
            val remaining = if (days > 0) "${days} д ${hours} ч ${minutes} мин" else "${hours} ч ${minutes} мин"
            val shiftName = when (type) {
                ShiftStore.DAY, ShiftStore.DAY_OVERTIME, ShiftStore.EXTRA_WORK -> "дневная"
                else -> "ночная"
            }
            val whenText = when (date) { today -> "сегодня"; today.plusDays(1) -> "завтра"; else -> "${date.dayOfMonth}.${date.monthValue}" }
            "До следующей ($shiftName, $whenText): $remaining"
        }
        val nextText = if (currentText != null) "$currentText\n$countdownText" else countdownText
        views.setTextViewText(R.id.widget_next_shift, nextText)
        views.setInt(R.id.legend_day_dot, "setBackgroundColor", ShiftStore.color(context, ShiftStore.DAY))
        views.setInt(R.id.legend_night_dot, "setBackgroundColor", ShiftStore.color(context, ShiftStore.NIGHT))
        views.setInt(R.id.legend_off_dot, "setBackgroundColor", ShiftStore.color(context, ShiftStore.OFF))
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.widget_month, open)
        manager.updateAppWidget(id, views)
    }

    companion object {
        private const val PREFS = "shift_widget_month"
        private const val MONTH_OFFSET = "month_offset"
        private const val ACTION_PREVIOUS = "com.example.shiftcalendar.PREVIOUS_MONTH"
        private const val ACTION_NEXT = "com.example.shiftcalendar.NEXT_MONTH"
        fun refresh(c: Context) {
            val manager = AppWidgetManager.getInstance(c)
            val ids = manager.getAppWidgetIds(ComponentName(c, MonthWidgetProvider::class.java))
            ids.forEach { updateStatic(c, manager, it) }
        }
        private fun updateStatic(c: Context, manager: AppWidgetManager, id: Int) {
            val intent = Intent(c, MonthWidgetProvider::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(id))
            c.sendBroadcast(intent)
        }
    }
}
