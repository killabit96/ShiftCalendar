package com.example.shiftcalendar

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

class MonthWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_PREVIOUS -> changeMonth(context, -1)
            ACTION_NEXT -> changeMonth(context, 1)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
    }

    private fun changeMonth(context: Context, delta: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val offset = prefs.getInt(MONTH_OFFSET, 0) + delta
        prefs.edit().putInt(MONTH_OFFSET, offset).apply()
        refresh(context)
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
        val views = RemoteViews(context.packageName, R.layout.month_widget)
        val offset = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(MONTH_OFFSET, 0)
        val month = YearMonth.now().plusMonths(offset.toLong())
        val monthName = month.month.getDisplayName(TextStyle.FULL_STANDALONE, Locale("ru")).replaceFirstChar { it.uppercase() }
        views.setTextViewText(R.id.widget_month, "$monthName ${month.year}")

        views.setOnClickPendingIntent(R.id.widget_prev_month, PendingIntent.getBroadcast(context, 101, Intent(context, MonthWidgetProvider::class.java).setAction(ACTION_PREVIOUS), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        views.setOnClickPendingIntent(R.id.widget_next_month, PendingIntent.getBroadcast(context, 102, Intent(context, MonthWidgetProvider::class.java).setAction(ACTION_NEXT), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

        views.removeAllViews(R.id.widget_grid)
        val cells = ShiftStore.monthCells(month).toMutableList()
        while (cells.size < 42) cells.add(null)
        cells.chunked(7).forEachIndexed { rowIndex, rowCells ->
            val row = RemoteViews(context.packageName, R.layout.widget_calendar_row)
            rowCells.forEachIndexed { colIndex, date ->
                val cell = RemoteViews(context.packageName, R.layout.widget_day_cell)
                if (date == null) {
                    cell.setTextViewText(R.id.day_number, "")
                    cell.setInt(R.id.day_number, "setBackgroundResource", R.drawable.day_cell_empty)
                } else {
                    val type = ShiftStore.type(context, date)
                    cell.setTextViewText(R.id.day_number, date.dayOfMonth.toString())
                    val color = ShiftStore.color(context, type)
                    val palette = intArrayOf(android.graphics.Color.rgb(0,132,255), android.graphics.Color.rgb(151,45,235), android.graphics.Color.rgb(48,183,77), android.graphics.Color.rgb(255,151,43), android.graphics.Color.rgb(35,190,190), android.graphics.Color.RED, android.graphics.Color.YELLOW, android.graphics.Color.CYAN, android.graphics.Color.MAGENTA)
                    val backgrounds = intArrayOf(R.drawable.day_color_0, R.drawable.day_color_1, R.drawable.day_color_2, R.drawable.day_color_3, R.drawable.day_color_4, R.drawable.day_color_5, R.drawable.day_color_6, R.drawable.day_color_7, R.drawable.day_color_8)
                    val colorIndex = palette.indexOf(color)
                    if (colorIndex >= 0) cell.setInt(R.id.day_number, "setBackgroundResource", backgrounds[colorIndex]) else cell.setInt(R.id.day_number, "setBackgroundColor", color)
                    val open = Intent(context, MainActivity::class.java).putExtra("selected_date", date.toString())
                    val pi = PendingIntent.getActivity(context, date.toEpochDay().toInt(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    cell.setOnClickPendingIntent(R.id.day_number, pi)
                }
                row.addView(R.id.widget_row, cell)
            }
            views.addView(R.id.widget_grid, row)
        }

        val today = LocalDate.now()
        val nextWork = (0L..60L).map { today.plusDays(it) }.firstOrNull {
            val type = ShiftStore.type(context, it)
            type == ShiftStore.DAY || type == ShiftStore.NIGHT || type == ShiftStore.EXTRA_WORK
        }
        val nextText = if (nextWork == null) "Ближайшая смена не найдена" else {
            val type = ShiftStore.type(context, nextWork)
            val label = when (type) { ShiftStore.DAY -> "Дневная смена"; ShiftStore.NIGHT -> "Ночная смена"; else -> "Дополнительная смена" }
            val whenText = when (nextWork) { today -> "сегодня"; today.plusDays(1) -> "завтра"; else -> "${nextWork.dayOfMonth}.${nextWork.monthValue}" }
            "Следующая: $label · $whenText"
        }
        views.setTextViewText(R.id.widget_next_shift, nextText)
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.widget_month, open)
        manager.updateAppWidget(id, views)
    }

    companion object {
        private const val PREFS = "shift_widget_month"
        private const val MONTH_OFFSET = "month_offset"
        private const val ACTION_PREVIOUS = "com.example.shiftcalendar.PREVIOUS_MONTH"
        private const val ACTION_NEXT = "com.example.shiftcalendar.NEXT_MONTH"
        fun refresh(c: Context) {
            val manager = AppWidgetManager.getInstance(c)
            val ids = manager.getAppWidgetIds(ComponentName(c, MonthWidgetProvider::class.java))
            ids.forEach { updateStatic(c, manager, it) }
        }
        private fun updateStatic(c: Context, manager: AppWidgetManager, id: Int) {
            val intent = Intent(c, MonthWidgetProvider::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE).putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, intArrayOf(id))
            c.sendBroadcast(intent)
        }
    }
}
