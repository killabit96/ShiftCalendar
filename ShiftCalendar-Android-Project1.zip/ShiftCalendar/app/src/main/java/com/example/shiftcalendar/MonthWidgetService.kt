package com.example.shiftcalendar

import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import java.time.LocalDate
import java.time.YearMonth

class MonthWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = MonthFactory(applicationContext)
    class MonthFactory(private val context: Context) : RemoteViewsFactory {
        private var cells: List<LocalDate?> = emptyList()
        override fun onCreate() = Unit
        override fun onDataSetChanged() { cells = ShiftStore.monthCells(YearMonth.now()) }
        override fun onDestroy() = Unit
        override fun getCount() = cells.size
        override fun getViewAt(position: Int): RemoteViews {
            val date = cells[position]
            val rv = RemoteViews(context.packageName, R.layout.widget_day_cell)
            if (date == null) { rv.setTextViewText(R.id.day_number, ""); rv.setInt(R.id.day_number, "setBackgroundResource", R.drawable.day_cell_empty) }
            else {
                val type = ShiftStore.type(context, date)
                rv.setTextViewText(R.id.day_number, date.dayOfMonth.toString())
                val color = ShiftStore.color(context, type)
                val palette = intArrayOf(
                    android.graphics.Color.rgb(0,132,255),
                    android.graphics.Color.rgb(151,45,235),
                    android.graphics.Color.rgb(48,183,77),
                    android.graphics.Color.rgb(255,151,43),
                    android.graphics.Color.rgb(35,190,190),
                    android.graphics.Color.RED,
                    android.graphics.Color.YELLOW,
                    android.graphics.Color.CYAN,
                    android.graphics.Color.MAGENTA
                )
                val backgrounds = intArrayOf(
                    R.drawable.day_color_0, R.drawable.day_color_1,
                    R.drawable.day_color_2, R.drawable.day_color_3,
                    R.drawable.day_color_4, R.drawable.day_color_5,
                    R.drawable.day_color_6, R.drawable.day_color_7,
                    R.drawable.day_color_8
                )
                val colorIndex = palette.indexOf(color)
                if (colorIndex >= 0) {
                    rv.setInt(R.id.day_number, "setBackgroundResource", backgrounds[colorIndex])
                } else {
                    // Keep arbitrary stored colors visible if a future color picker is added.
                    rv.setInt(R.id.day_number, "setBackgroundColor", color)
                }
                val fillIntent = Intent(context, MainActivity::class.java)
                rv.setOnClickFillInIntent(R.id.day_number, fillIntent)
            }
            return rv
        }
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = cells[position]?.toEpochDay() ?: position.toLong()
        override fun hasStableIds() = true
    }
}
